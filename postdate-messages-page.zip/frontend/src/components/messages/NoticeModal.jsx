import { useEffect } from "react";

/**
 * NoticeModal
 * The shared "NOTICE!" confirmation shell — maroon card, cream inset body,
 * NO / confirm buttons. Used directly for Unmatch and Block, and reused (via
 * `wide` + `children`) as the outer chrome for ReportModal so the two share
 * one implementation of the backdrop, Escape-to-close, and button styling.
 *
 * The confirm button always gets the same green border the rest of the app
 * uses for "this button proceeds" (see TasteTab's ✔ save button) — the
 * Figma keeps that green on Block's confirm button too, even though Block is
 * a "negative" action, so the colour tracks "proceeds" rather than the
 * action's tone.
 *
 * Usage:
 *   <NoticeModal open={open} confirmLabel="Unmatch" onClose={...} onConfirm={...}>
 *     Are you sure you want to unmatch Alex?
 *   </NoticeModal>
 */
export default function NoticeModal({
  open,
  title = "Notice!",
  confirmLabel = "Confirm",
  confirmDisabled = false,
  wide = false,
  onClose,
  onConfirm,
  children,
}) {
  useEffect(() => {
    if (!open) return;
    function onKey(e) {
      if (e.key === "Escape") onClose?.();
    }
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="notice-backdrop"
      role="presentation"
      onClick={(e) => e.target === e.currentTarget && onClose?.()}
    >
      <style>{`
        .notice-backdrop {
          position: fixed;
          inset: 0;
          z-index: 60;
          display: grid;
          place-items: center;
          padding: 20px;
          background: rgba(43, 35, 32, 0.45);
          backdrop-filter: blur(4px);
        }
        .notice-card {
          position: relative;
          width: min(94vw, var(--notice-width, 420px));
          background: var(--pd-maroon);
          border: 10px solid var(--pd-pink);
          border-radius: 14px;
          padding: clamp(16px, 2.4vw, 26px);
          box-shadow: 0 30px 60px -24px rgba(43, 35, 32, 0.55);
        }
        .notice-close {
          position: absolute;
          top: 8px;
          right: 12px;
          background: none;
          border: none;
          font-size: 24px;
          color: var(--pd-white);
          opacity: 0.85;
          cursor: pointer;
          line-height: 1;
        }
        .notice-close:hover { opacity: 1; }
        .notice-title {
          margin: 0 0 clamp(10px, 1.6vw, 18px);
          font-family: var(--pd-mono);
          font-size: clamp(20px, 2.6vw, 30px);
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--pd-cream);
          text-align: center;
        }
        .notice-body {
          background: var(--pd-cream);
          border-radius: 10px;
          padding: clamp(14px, 2vw, 22px);
          font-family: var(--pd-mono);
          font-weight: 700;
          font-size: clamp(14px, 1.5vw, 19px);
          line-height: 1.5;
          color: var(--pd-ink);
          text-align: center;
        }
        .notice-actions {
          display: flex;
          justify-content: center;
          gap: clamp(10px, 1.4vw, 20px);
          margin-top: clamp(14px, 1.8vw, 22px);
        }
        .notice-btn {
          background: var(--pd-cream);
          border-radius: 30px;
          padding: clamp(8px, 0.9vw, 12px) clamp(20px, 2.6vw, 34px);
          box-shadow: 0 4px 4px rgba(0, 0, 0, 0.25);
          font-family: var(--pd-mono);
          font-size: clamp(13px, 1.3vw, 18px);
          letter-spacing: 0.03em;
          text-transform: uppercase;
          cursor: pointer;
          transition: transform 0.15s ease;
        }
        .notice-btn:hover { transform: translateY(-2px); }
        .notice-btn:disabled { opacity: 0.55; cursor: default; transform: none; }
        .notice-btn-no { border: 6px solid var(--pd-ink); color: var(--pd-ink); }
        .notice-btn-confirm { border: 6px solid var(--pd-green); color: var(--pd-green); }
      `}</style>

      <div
        className="notice-card"
        role="alertdialog"
        aria-modal="true"
        aria-label={title}
        style={{ "--notice-width": wide ? "700px" : "420px" }}
      >
        <button type="button" className="notice-close" onClick={onClose} aria-label="Close">
          ×
        </button>

        <h2 className="notice-title">{title}</h2>

        <div className="notice-body">{children}</div>

        <div className="notice-actions">
          <button type="button" className="notice-btn notice-btn-no" onClick={onClose}>
            No
          </button>
          <button
            type="button"
            className="notice-btn notice-btn-confirm"
            onClick={onConfirm}
            disabled={confirmDisabled}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
