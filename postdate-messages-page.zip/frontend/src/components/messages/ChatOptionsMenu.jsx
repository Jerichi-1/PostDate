/**
 * ChatOptionsMenu
 * The small "NAME" card that drops down off the chat header's "..." button:
 * three quick-action icons, then Unmatch / Block / Report. Report keeps the
 * dark ink pill from the Figma so it reads as the most serious of the three.
 *
 * 🔍 CONFIDENCE NOTE: the export gives the three icons as bare emoji
 * (🔔 🧑 🔍) with no labels attached to say what they do. I mapped them to
 * the three things a chat overflow menu usually needs — mute this
 * conversation, view the person's profile, and search inside the thread —
 * and drew them as the same thin-stroke inline SVGs the rest of the app uses
 * (see DiscoverToolbar's search icon) instead of emoji, so they render the
 * same on every OS. None of the three are wired to real behaviour yet; swap
 * this file if your Figma meant something else by them.
 *
 * Usage:
 *   <ChatOptionsMenu name="Alex" onUnmatch={...} onBlock={...} onReport={...} />
 */
export default function ChatOptionsMenu({ name, onUnmatch, onBlock, onReport }) {
  return (
    <div className="coptions" role="menu" aria-label={`Options for ${name}`}>
      <style>{`
        .coptions {
          position: absolute;
          top: calc(100% + 10px);
          right: 0;
          z-index: 20;
          width: clamp(210px, 22vw, 290px);

          background: var(--pd-maroon);
          border-radius: 16px;
          padding: clamp(10px, 1.2vw, 18px);
          box-shadow: 0 18px 34px -18px rgba(43, 35, 32, 0.55);

          display: flex;
          flex-direction: column;
          gap: clamp(8px, 1vw, 14px);
        }
        .coptions-name {
          margin: 0;
          text-align: center;
          font-family: var(--pd-mono);
          font-size: clamp(15px, 1.6vw, 22px);
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--pd-white);
        }
        .coptions-icons {
          display: flex;
          background: var(--pd-pink);
          border-radius: 20px;
          overflow: hidden;
        }
        .coptions-icons button {
          flex: 1;
          display: grid;
          place-items: center;
          background: none;
          border: none;
          border-right: 1px solid var(--pd-maroon);
          padding: clamp(9px, 1.1vw, 15px) 0;
          cursor: pointer;
          color: var(--pd-ink);
        }
        .coptions-icons button:last-child { border-right: none; }
        .coptions-icons button:hover { color: var(--pd-maroon); background: rgba(179, 57, 81, 0.12); }
        .coptions-icons svg { width: clamp(16px, 1.6vw, 22px); height: auto; }

        .coptions-action {
          background: var(--pd-pink);
          border: none;
          border-radius: 20px;
          padding: clamp(9px, 1.1vw, 15px) 0;
          cursor: pointer;
          font-family: var(--pd-mono);
          font-size: clamp(12px, 1.2vw, 16px);
          letter-spacing: 0.05em;
          text-transform: uppercase;
          color: var(--pd-ink);
        }
        .coptions-action:hover { filter: brightness(0.97); }
        .coptions-action-report {
          background: var(--pd-ink);
          color: var(--pd-cream);
        }
      `}</style>

      <p className="coptions-name">{name}</p>

      <div className="coptions-icons">
        <button type="button" title="Mute notifications" aria-label="Mute notifications">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <path d="M12 3a3 3 0 0 0-3 3v5l-2 3v1h14v-1l-2-3V6a3 3 0 0 0-3-3Z" strokeLinejoin="round" />
            <path d="M10 19a2 2 0 0 0 4 0" />
          </svg>
        </button>
        <button type="button" title={`View ${name}'s profile`} aria-label={`View ${name}'s profile`}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <circle cx="12" cy="8" r="3.4" />
            <path d="M5 20c1.4-3.6 4.2-5.4 7-5.4S18.6 16.4 20 20" strokeLinecap="round" />
          </svg>
        </button>
        <button type="button" title="Search this conversation" aria-label="Search this conversation">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5" />
            <line x1="20" y1="20" x2="15.8" y2="15.8" />
          </svg>
        </button>
      </div>

      <button type="button" className="coptions-action" role="menuitem" onClick={onUnmatch}>
        Unmatch
      </button>
      <button type="button" className="coptions-action" role="menuitem" onClick={onBlock}>
        Block
      </button>
      <button
        type="button"
        className="coptions-action coptions-action-report"
        role="menuitem"
        onClick={onReport}
      >
        Report
      </button>
    </div>
  );
}
