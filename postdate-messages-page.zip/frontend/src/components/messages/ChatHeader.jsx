import { useEffect, useRef, useState } from "react";
import ChatOptionsMenu from "./ChatOptionsMenu";

/**
 * ChatHeader
 * Avatar + name + distance for whichever match is open, plus the "..."
 * button that drops down into ChatOptionsMenu. Closes on Escape or a click
 * outside, same pattern ProfileModal/DiscoverToolbar already use.
 *
 * Usage:
 *   <ChatHeader conversation={active} onUnmatch={...} onBlock={...} onReport={...} />
 */
export default function ChatHeader({ conversation, onUnmatch, onBlock, onReport }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    function onDocClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setMenuOpen(false);
    }
    function onKey(e) {
      if (e.key === "Escape") setMenuOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [menuOpen]);

  if (!conversation) return null;
  const { name, distanceMi, avatarUrl } = conversation;

  return (
    <header className="chdr">
      <style>{`
        .chdr {
          position: relative;
          flex: none;
          display: flex;
          align-items: center;
          gap: clamp(10px, 1.2vw, 18px);
          padding-bottom: clamp(10px, 1.4vw, 20px);
          margin-bottom: clamp(10px, 1.4vw, 20px);
          border-bottom: 3px solid var(--pd-maroon);
        }
        .chdr-avatar {
          flex: none;
          width: clamp(44px, 4.7vw, 84px);
          height: clamp(44px, 4.7vw, 84px);
          border-radius: 50%;
          background: var(--pd-salmon);
          object-fit: cover;
        }
        .chdr-text { flex: 1; min-width: 0; }
        .chdr-name {
          margin: 0;
          font-family: var(--pd-mono);
          font-weight: 400;
          font-size: clamp(17px, 2.2vw, 36px);
          color: var(--pd-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .chdr-distance {
          margin: 2px 0 0;
          font-family: var(--pd-mono);
          font-size: clamp(10px, 0.85vw, 14px);
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--pd-salmon);
        }
        .chdr-more {
          flex: none;
          background: none;
          border: none;
          cursor: pointer;
          font-family: var(--pd-mono);
          font-weight: 700;
          font-size: clamp(20px, 2vw, 30px);
          color: var(--pd-ink);
          padding: 4px 10px;
          line-height: 1;
        }
        .chdr-more:hover { color: var(--pd-maroon); }
      `}</style>

      {avatarUrl ? (
        <img className="chdr-avatar" src={avatarUrl} alt="" />
      ) : (
        <span className="chdr-avatar" aria-hidden="true" />
      )}

      <div className="chdr-text">
        <h1 className="chdr-name">{name}</h1>
        <p className="chdr-distance">Distance: {distanceMi} mi</p>
      </div>

      <div ref={wrapRef} style={{ position: "relative" }}>
        <button
          type="button"
          className="chdr-more"
          aria-haspopup="true"
          aria-expanded={menuOpen}
          aria-label={`More options for ${name}`}
          onClick={() => setMenuOpen((v) => !v)}
        >
          •••
        </button>

        {menuOpen && (
          <ChatOptionsMenu
            name={name}
            onUnmatch={() => {
              setMenuOpen(false);
              onUnmatch?.();
            }}
            onBlock={() => {
              setMenuOpen(false);
              onBlock?.();
            }}
            onReport={() => {
              setMenuOpen(false);
              onReport?.();
            }}
          />
        )}
      </div>
    </header>
  );
}
