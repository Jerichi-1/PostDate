import { useEffect, useRef, useState } from "react";
import MessageBubble from "./MessageBubble";

/**
 * MessageThread
 * The scrollable list of bubbles for whichever match is open. Always scrolls
 * to the newest message when you open a conversation or send one.
 *
 * 🔍 CONFIDENCE NOTE: the Figma's notifications panel has a literal
 * "infinite scroll" label under an up-arrow button — read as a note to
 * whoever builds this, not copy meant for end users. I built it as a real
 * "load earlier messages" control instead of shipping that placeholder text
 * (see the README's messages-page section).
 *
 * Usage:
 *   <MessageThread messages={messages} loading={false} hasMore={true} onLoadEarlier={fn} />
 */
export default function MessageThread({
  messages = [],
  loading,
  hasMore = false,
  onLoadEarlier,
}) {
  const endRef = useRef(null);
  const [loadingMore, setLoadingMore] = useState(false);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  async function handleLoadEarlier() {
    if (!onLoadEarlier || loadingMore) return;
    setLoadingMore(true);
    try {
      await onLoadEarlier();
    } finally {
      setLoadingMore(false);
    }
  }

  return (
    <div className="mthread">
      <style>{`
        .mthread {
          flex: 1;
          min-height: 0;
          overflow-y: auto;
          display: flex;
          flex-direction: column;
          gap: clamp(10px, 1.2vw, 18px);
          padding: 4px clamp(2px, 0.6vw, 8px);
        }
        .mthread-load {
          align-self: center;
          flex: none;
          width: 34px;
          height: 34px;
          margin-bottom: 4px;
          border-radius: 50%;
          border: none;
          background: var(--pd-cream);
          color: var(--pd-maroon);
          display: grid;
          place-items: center;
          cursor: pointer;
          box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15);
        }
        .mthread-load svg { width: 15px; height: 15px; }
        .mthread-load:disabled { opacity: 0.6; cursor: default; }
        .mthread-status {
          margin: auto;
          font-family: var(--pd-mono);
          font-size: 13px;
          color: var(--pd-maroon);
          text-align: center;
          max-width: 32ch;
        }
      `}</style>

      {loading && <p className="mthread-status">Loading conversation…</p>}

      {!loading && messages.length === 0 && (
        <p className="mthread-status">No messages yet — say hi to start the conversation.</p>
      )}

      {!loading && hasMore && (
        <button
          type="button"
          className="mthread-load"
          onClick={handleLoadEarlier}
          disabled={loadingMore}
          aria-label="Load earlier messages"
          title="Load earlier messages"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
            <line x1="12" y1="19" x2="12" y2="5" />
            <polyline points="6 11 12 5 18 11" />
          </svg>
        </button>
      )}

      {messages.map((m) => (
        <MessageBubble key={m.id} message={m} />
      ))}

      <div ref={endRef} />
    </div>
  );
}
