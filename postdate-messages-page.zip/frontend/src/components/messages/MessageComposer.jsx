import { useRef, useState } from "react";

/**
 * MessageComposer
 * The bottom bar. The "+" is a hidden file input that fires the moment you
 * pick a photo — same click-to-open-hidden-input trick as PhotosForm's
 * dropzone — so attaching a photo just sends it, no separate confirm step.
 *
 * Usage:
 *   <MessageComposer onSend={({ text, photoFile }) => ...} />
 */
export default function MessageComposer({ onSend, disabled }) {
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const fileRef = useRef(null);

  async function submitText(e) {
    e?.preventDefault();
    const trimmed = text.trim();
    if (!trimmed || sending || disabled) return;
    setSending(true);
    try {
      await onSend?.({ text: trimmed, photoFile: null });
      setText("");
    } finally {
      setSending(false);
    }
  }

  async function handlePhoto(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file || sending || disabled) return;
    setSending(true);
    try {
      await onSend?.({ text: "", photoFile: file });
    } finally {
      setSending(false);
    }
  }

  return (
    <form className="mcomposer" onSubmit={submitText}>
      <style>{`
        .mcomposer {
          flex: none;
          margin-top: clamp(10px, 1.4vw, 20px);
          background: var(--pd-salmon);
          border-radius: 8px;
          padding: clamp(6px, 0.8vw, 12px);
          display: flex;
          align-items: center;
          gap: clamp(8px, 1vw, 16px);
        }
        .mcomposer-attach {
          flex: none;
          width: clamp(34px, 3.4vw, 52px);
          height: clamp(34px, 3.4vw, 52px);
          border-radius: 50%;
          border: none;
          background: transparent;
          color: var(--pd-white);
          font-family: var(--pd-mono);
          font-size: clamp(24px, 3vw, 44px);
          line-height: 1;
          cursor: pointer;
        }
        .mcomposer-attach:hover { color: var(--pd-cream); }
        .mcomposer-attach:disabled { opacity: 0.6; cursor: default; }
        .mcomposer-input {
          flex: 1;
          min-width: 0;
          background: var(--pd-cream);
          border: none;
          border-radius: 9px;
          padding: clamp(10px, 1.1vw, 16px) clamp(12px, 1.4vw, 20px);
          font-family: var(--pd-mono);
          font-size: clamp(13px, 1.2vw, 20px);
          color: var(--pd-maroon);
        }
        .mcomposer-input::placeholder { color: var(--pd-maroon); opacity: 0.7; }
        .mcomposer-send {
          flex: none;
          background: var(--pd-cream);
          border: 6px solid var(--pd-green);
          box-shadow: 0 4px 4px rgba(0, 0, 0, 0.25);
          border-radius: 30px;
          padding: clamp(8px, 0.9vw, 13px) clamp(16px, 1.8vw, 28px);
          font-family: var(--pd-mono);
          font-size: clamp(12px, 1.3vw, 20px);
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--pd-green);
          cursor: pointer;
        }
        .mcomposer-send:disabled { opacity: 0.55; cursor: default; }
        .mcomposer-hidden-input {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border: 0;
        }
      `}</style>

      <button
        type="button"
        className="mcomposer-attach"
        onClick={() => fileRef.current?.click()}
        aria-label="Send a photo"
        title="Send a photo"
        disabled={disabled || sending}
      >
        +
      </button>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        className="mcomposer-hidden-input"
        tabIndex={-1}
        onChange={handlePhoto}
      />

      <input
        type="text"
        className="mcomposer-input"
        placeholder="Type here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        disabled={disabled || sending}
        aria-label="Message"
      />

      <button
        type="submit"
        className="mcomposer-send"
        disabled={disabled || sending || !text.trim()}
      >
        {sending ? "…" : "Send"}
      </button>
    </form>
  );
}
