import { useEffect, useRef, useState } from "react";
import { getNotifications } from "../../services/postdateApi";

/**
 * NotificationsBell
 * The bell that sits beside AppNav's pill on this page (see AppNav.jsx and
 * the README — the Discover/Profile Figma captures never showed a bell, so
 * it isn't baked into AppNav for every page; it's dropped in here through
 * the `children` slot AppNav now exposes). Click it for likes, reviews, and
 * system notices, with a "load more" control standing in for the export's
 * "infinite scroll" note — see the README's messages-page section.
 *
 * Usage:
 *   <AppNav><NotificationsBell /></AppNav>
 */
export default function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const wrapRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    getNotifications()
      .then(({ notifications, hasMore: more }) => {
        if (cancelled) return;
        setItems(notifications);
        setHasMore(more);
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    function onDocClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    }
    function onKey(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  async function handleLoadMore() {
    if (loadingMore) return;
    setLoadingMore(true);
    try {
      const { notifications, hasMore: more } = await getNotifications({
        before: items[items.length - 1]?.id,
      });
      setItems((prev) => [...prev, ...notifications]);
      setHasMore(more);
    } finally {
      setLoadingMore(false);
    }
  }

  const unreadCount = items.filter((n) => !n.read).length;

  return (
    <div className="nbell" ref={wrapRef}>
      <style>{`
        .nbell { position: relative; }
        .nbell-button {
          position: relative;
          display: grid;
          place-items: center;
          width: clamp(28px, 2.6vw, 42px);
          height: clamp(28px, 2.6vw, 42px);
          background: none;
          border: none;
          color: var(--pd-white);
          cursor: pointer;
        }
        .nbell-button:hover { color: var(--pd-salmon); }
        .nbell-button svg { width: 60%; height: 60%; }
        .nbell-dot {
          position: absolute;
          top: 2px;
          right: 2px;
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background: #f80000;
          border: 2px solid var(--pd-maroon);
        }
        .nbell-panel {
          position: absolute;
          top: calc(100% + 14px);
          left: 50%;
          transform: translateX(-50%);
          z-index: 30;
          width: clamp(240px, 24vw, 320px);
          max-height: 60vh;
          overflow-y: auto;

          background: var(--pd-maroon);
          border-radius: 16px;
          padding: clamp(12px, 1.4vw, 20px);
          box-shadow: 0 18px 34px -18px rgba(43, 35, 32, 0.55);

          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        .nbell-panel::before {
          content: "";
          position: absolute;
          top: -8px;
          left: 50%;
          transform: translateX(-50%);
          border: 8px solid transparent;
          border-bottom-color: var(--pd-maroon);
        }
        .nbell-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding-bottom: 10px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        }
        .nbell-item:last-of-type { border-bottom: none; padding-bottom: 0; }
        .nbell-avatar {
          flex: none;
          width: 34px;
          height: 34px;
          border-radius: 50%;
          background: var(--pd-salmon);
        }
        .nbell-avatar-system {
          background: var(--pd-ink);
          display: grid;
          place-items: center;
          color: var(--pd-white);
          font-family: var(--pd-mono);
          font-weight: 700;
        }
        .nbell-text {
          margin: 0;
          font-family: var(--pd-mono);
          font-size: 13px;
          line-height: 1.4;
          color: var(--pd-cream);
        }
        .nbell-status {
          margin: 0;
          font-family: var(--pd-mono);
          font-size: 12px;
          color: var(--pd-cream);
          text-align: center;
        }
        .nbell-more {
          align-self: center;
          width: 34px;
          height: 34px;
          border-radius: 50%;
          border: none;
          background: var(--pd-cream);
          color: var(--pd-maroon);
          display: grid;
          place-items: center;
          cursor: pointer;
        }
        .nbell-more svg { width: 15px; height: 15px; }
        .nbell-more:disabled { opacity: 0.6; cursor: default; }
      `}</style>

      <button
        type="button"
        className="nbell-button"
        aria-haspopup="true"
        aria-expanded={open}
        aria-label={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : "Notifications"}
        onClick={() => setOpen((v) => !v)}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
          <path d="M12 3a3 3 0 0 0-3 3v5l-2 3v1h14v-1l-2-3V6a3 3 0 0 0-3-3Z" strokeLinejoin="round" />
          <path d="M10 19a2 2 0 0 0 4 0" />
        </svg>
        {unreadCount > 0 && <span className="nbell-dot" aria-hidden="true" />}
      </button>

      {open && (
        <div className="nbell-panel" role="menu" aria-label="Notifications">
          {loading && <p className="nbell-status">Loading…</p>}
          {!loading && items.length === 0 && <p className="nbell-status">Nothing yet.</p>}

          {items.map((n) => (
            <div className="nbell-item" key={n.id}>
              {n.type === "system" ? (
                <span className="nbell-avatar nbell-avatar-system" aria-hidden="true">
                  !
                </span>
              ) : (
                <span className="nbell-avatar" aria-hidden="true" />
              )}
              <p className="nbell-text">{n.text}</p>
            </div>
          ))}

          {!loading && hasMore && (
            <button
              type="button"
              className="nbell-more"
              onClick={handleLoadMore}
              disabled={loadingMore}
              aria-label="Load more notifications"
              title="Load more notifications"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" aria-hidden="true">
                <line x1="12" y1="19" x2="12" y2="5" />
                <polyline points="6 11 12 5 18 11" />
              </svg>
            </button>
          )}
        </div>
      )}
    </div>
  );
}
