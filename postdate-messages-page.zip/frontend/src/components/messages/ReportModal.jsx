import { useState } from "react";
import NoticeModal from "./NoticeModal";

/* 🎛️ EDIT THE REPORT REASONS HERE */
const REASONS = ["Harassment", "Spam", "Fake profile", "Inappropriate", "Other"];

/**
 * ReportModal
 * Reuses NoticeModal's chrome (wide, since the Figma draws Report's card
 * much bigger than Unmatch/Block's) and adds the reason radio list plus the
 * "state other..." field that only shows up once "Other" is picked. Report
 * is disabled until a reason is chosen.
 *
 * Usage:
 *   <ReportModal open={open} name="Alex" onClose={...}
 *     onSubmit={({ reason, details }) => ...} />
 */
export default function ReportModal({ open, name, onClose, onSubmit }) {
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function handleClose() {
    if (submitting) return;
    setReason("");
    setDetails("");
    onClose?.();
  }

  async function handleConfirm() {
    if (!reason || submitting) return;
    setSubmitting(true);
    try {
      await onSubmit?.({ reason, details: reason === "Other" ? details : "" });
      setReason("");
      setDetails("");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <NoticeModal
      open={open}
      wide
      confirmLabel={submitting ? "Sending…" : "Report"}
      confirmDisabled={!reason || submitting}
      onClose={handleClose}
      onConfirm={handleConfirm}
    >
      <style>{`
        .report-question { margin: 0 0 clamp(10px, 1.4vw, 18px); }
        .report-reasons {
          border: none;
          margin: 0;
          padding: 0;
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 8px 20px;
          text-align: left;
          font-weight: 400;
        }
        .report-reason {
          display: flex;
          align-items: center;
          gap: 8px;
          cursor: pointer;
          font-size: clamp(13px, 1.3vw, 17px);
        }
        .report-reason input { accent-color: var(--pd-maroon); }
        .report-other {
          margin-top: 14px;
          width: 100%;
          min-height: 76px;
          border: none;
          border-radius: 5px;
          background: var(--pd-tan);
          color: var(--pd-ink);
          font-family: var(--pd-mono);
          font-weight: 400;
          font-size: 13px;
          padding: 10px 12px;
          resize: vertical;
        }
        .report-other::placeholder { color: var(--pd-cream); opacity: 0.95; }
        @media (max-width: 480px) {
          .report-reasons { grid-template-columns: 1fr; }
        }
      `}</style>

      <p className="report-question">
        Are you sure you want to report <strong>{name}</strong>?
      </p>

      <fieldset className="report-reasons">
        <legend className="visually-hidden">Reason</legend>
        {REASONS.map((r) => (
          <label className="report-reason" key={r}>
            <input
              type="radio"
              name="report-reason"
              value={r}
              checked={reason === r}
              onChange={() => setReason(r)}
            />
            {r}
          </label>
        ))}
      </fieldset>

      {reason === "Other" && (
        <textarea
          className="report-other"
          placeholder="State other..."
          value={details}
          onChange={(e) => setDetails(e.target.value)}
          aria-label="Describe the reason"
        />
      )}
    </NoticeModal>
  );
}
