/**
 * MessageBubble
 * One row in the thread. Their messages sit left with a small avatar; yours
 * sit right in maroon with a seen/sent dot underneath — filled once they've
 * read it, hollow while it's still just sent. That maps straight onto the
 * `read` boolean already on the Message model (backend/models/Message.js),
 * so a real backend only has to keep setting that flag the same way.
 *
 * Usage:
 *   <MessageBubble message={{ senderId: "them", message: "hi", read: true }} />
 *   <MessageBubble message={{ senderId: "me", photoUrl: "...", read: false }} />
 */
export default function MessageBubble({ message }) {
  const mine = message.senderId === "me";

  return (
    <div className={`mbubble-row${mine ? " mbubble-row-mine" : ""}`}>
      <style>{`
        .mbubble-row {
          display: flex;
          align-items: flex-end;
          gap: 8px;
          max-width: 80%;
        }
        .mbubble-row-mine {
          align-self: flex-end;
          flex-direction: row-reverse;
        }
        .mbubble-avatar {
          flex: none;
          width: clamp(24px, 2.4vw, 38px);
          height: clamp(24px, 2.4vw, 38px);
          border-radius: 50%;
          background: var(--pd-salmon);
        }
        .mbubble-col {
          display: flex;
          flex-direction: column;
          gap: 4px;
          min-width: 0;
        }
        .mbubble-row-mine .mbubble-col { align-items: flex-end; }

        .mbubble-bubble {
          padding: clamp(8px, 1vw, 14px) clamp(12px, 1.3vw, 18px);
          border-radius: 16px;
          font-family: var(--pd-mono);
          font-size: clamp(12px, 1.05vw, 16px);
          line-height: 1.45;
          word-break: break-word;
        }
        .mbubble-row:not(.mbubble-row-mine) .mbubble-bubble {
          background: var(--pd-pink);
          color: var(--pd-ink);
          border-bottom-left-radius: 4px;
        }
        .mbubble-row-mine .mbubble-bubble {
          background: var(--pd-maroon);
          color: var(--pd-cream);
          border-bottom-right-radius: 4px;
        }
        .mbubble-photo {
          display: block;
          width: clamp(120px, 16vw, 220px);
          max-width: 100%;
          height: auto;
          border-radius: 12px;
        }
        .mbubble-photo + span { display: block; margin-top: 6px; }

        .mbubble-status {
          display: flex;
          align-items: center;
          gap: 5px;
          font-family: var(--pd-mono);
          font-size: 10px;
          letter-spacing: 0.04em;
          text-transform: uppercase;
          color: var(--pd-maroon);
          opacity: 0.75;
        }
        .mbubble-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          border: 1.5px solid var(--pd-maroon);
          box-sizing: border-box;
        }
        .mbubble-dot-filled { background: var(--pd-maroon); }
      `}</style>

      {!mine && <span className="mbubble-avatar" aria-hidden="true" />}

      <div className="mbubble-col">
        <div className="mbubble-bubble">
          {message.photoUrl && (
            <img className="mbubble-photo" src={message.photoUrl} alt="Shared" />
          )}
          {message.message && <span>{message.message}</span>}
        </div>

        {mine && (
          <span className="mbubble-status">
            <span
              className={`mbubble-dot${message.read ? " mbubble-dot-filled" : ""}`}
              aria-hidden="true"
            />
            {message.read ? "Seen" : "Sent"}
          </span>
        )}
      </div>
    </div>
  );
}
