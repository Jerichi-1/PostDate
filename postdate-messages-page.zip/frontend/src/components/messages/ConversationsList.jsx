/**
 * ConversationsList
 * The "DASHBOARD" column on the messages page: one pill row per match —
 * avatar, name, last-message preview, unread count. The open conversation
 * gets the dark-ink background from the mockup; every other row stays
 * cream, exactly like the admin dashboard's own sidebar pattern
 * (components/admin/AdminSidebar.jsx), just carrying match data instead of
 * static labels.
 *
 * Usage:
 *   <ConversationsList conversations={list} activeId={id} onSelect={setId} />
 */
export default function ConversationsList({
  conversations = [],
  activeId,
  onSelect,
  loading,
}) {
  return (
    <nav className="clist" aria-label="Conversations">
      <style>{`
        .clist {
          display: flex;
          flex-direction: column;
          gap: clamp(10px, 1.2vw, 18px);
        }
        .clist-title {
          margin: 0 0 clamp(4px, 0.6vw, 8px);
          font-family: var(--pd-mono);
          font-weight: 400;
          font-size: clamp(15px, 1.7vw, 30px);
          letter-spacing: 0.03em;
          text-transform: uppercase;
          color: var(--pd-white);
        }
        .clist-item {
          display: flex;
          align-items: center;
          gap: clamp(8px, 1vw, 16px);
          background: var(--pd-cream);
          border: none;
          border-radius: 20px;
          padding: clamp(8px, 1vw, 16px);
          cursor: pointer;
          text-align: left;
          transition: transform 0.15s ease, background-color 0.15s ease;
        }
        .clist-item:hover { transform: translateX(2px); }
        .clist-item[aria-current="true"] { background: var(--pd-ink); }

        .clist-avatar-wrap { position: relative; flex: none; }
        .clist-avatar {
          display: block;
          width: clamp(40px, 4.7vw, 74px);
          height: clamp(40px, 4.7vw, 74px);
          border-radius: 50%;
          background: var(--pd-salmon);
          object-fit: cover;
        }
        .clist-dot {
          position: absolute;
          right: 0;
          bottom: 0;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: var(--pd-green);
          border: 2px solid var(--pd-cream);
        }
        .clist-item[aria-current="true"] .clist-dot { border-color: var(--pd-ink); }

        .clist-text { min-width: 0; flex: 1; }
        .clist-name {
          margin: 0;
          font-family: var(--pd-mono);
          font-size: clamp(13px, 1.4vw, 24px);
          color: var(--pd-ink);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .clist-item[aria-current="true"] .clist-name { color: var(--pd-white); }
        .clist-preview {
          margin: 2px 0 0;
          font-family: var(--pd-mono);
          font-size: clamp(10px, 0.85vw, 14px);
          color: var(--pd-salmon);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .clist-unread {
          flex: none;
          min-width: 22px;
          height: 22px;
          padding: 0 6px;
          border-radius: 11px;
          background: var(--pd-salmon);
          color: var(--pd-white);
          font-family: var(--pd-mono);
          font-size: 11px;
          display: grid;
          place-items: center;
        }
        .clist-empty {
          margin: 0;
          font-family: var(--pd-mono);
          font-size: 13px;
          line-height: 1.6;
          color: var(--pd-white);
          opacity: 0.85;
        }

        @media (max-width: 760px) {
          .clist { flex-direction: row; flex-wrap: wrap; }
          .clist-title { width: 100%; }
          .clist-item { flex: 1 1 220px; }
        }
      `}</style>

      <h2 className="clist-title">Dashboard</h2>

      {loading && <p className="clist-empty">Loading matches…</p>}

      {!loading && conversations.length === 0 && (
        <p className="clist-empty">
          No matches yet. Head to Home and like a few profiles to start conversations.
        </p>
      )}

      {conversations.map((c) => (
        <button
          key={c.matchId}
          type="button"
          className="clist-item"
          aria-current={c.matchId === activeId ? "true" : undefined}
          onClick={() => onSelect?.(c.matchId)}
        >
          <span className="clist-avatar-wrap">
            {c.avatarUrl ? (
              <img className="clist-avatar" src={c.avatarUrl} alt="" />
            ) : (
              <span className="clist-avatar" aria-hidden="true" />
            )}
            {c.online && <span className="clist-dot" aria-hidden="true" />}
          </span>

          <span className="clist-text">
            <p className="clist-name">{c.name}</p>
            <p className="clist-preview">
              {c.name}: {c.lastMessage}
            </p>
          </span>

          {c.unreadCount > 0 && <span className="clist-unread">{c.unreadCount}</span>}
        </button>
      ))}
    </nav>
  );
}
