/**
 * Messages — the chat / DM page: a maroon "inbox" card holding the matches
 * list on the left and the open conversation on the right, plus the bell's
 * notifications panel and the report/block/unmatch flow off the chat
 * header's "..." menu.
 *
 *   ┌──────────────────────────────────────────────────┐
 *   │ POSTDATE!         🔔   HOME  MESSAGES  PROFILE   │  AppNav (+ bell)
 *   ├──────────────────────────────────────────────────┤
 *   │ ┌────────────┐┌─────────────────────────────────┐│
 *   │ │ DASHBOARD  ││ avatar NAME · distance      ...  ││
 *   │ │ (match 1)  │├─────────────────────────────────┤│  maroon card
 *   │ │ (match 2)  ││        message thread           ││
 *   │ │ ...        ││                                  ││
 *   │ └────────────┘│  + [ type here... ]      SEND    ││
 *   │                └─────────────────────────────────┘│
 *   └──────────────────────────────────────────────────┘
 *
 * 🔍 CONFIDENCE NOTE — read this before you trust it blindly (same spirit as
 * Discover's note in the README). A few calls I made where the Figma export
 * didn't spell out the answer:
 *   - The bell only showed up on this frame, not on Discover's or Profile's
 *     captures, so I didn't bake it into AppNav for every page — AppNav now
 *     has an optional `children` slot rendered next to the pill, and this
 *     page is the only one that fills it (see components/AppNav.jsx).
 *   - The "..." menu's three icons were bare emoji with no labels attached.
 *     I mapped them to mute / view profile / search-in-chat — see
 *     components/messages/ChatOptionsMenu.jsx if that's not what you meant.
 *   - The notifications panel's "infinite scroll" text and the base chat
 *     view's stray up-arrow button both read as build notes, not literal
 *     copy, so both became real "load more" controls instead — one for
 *     older notifications, one for older messages.
 *   - The export's message-bubble colour only clearly shows the *received*
 *     side (pink). I picked maroon for *your* bubbles so the two are always
 *     tellable apart; there wasn't a second colour to read off the export.
 *   - One notification's text in the export is dark ink on the maroon
 *     panel, which nothing else on the site does (every other maroon
 *     surface — the nav pill, the sidebar pills, the footer — pairs maroon
 *     with white/cream text). Treated as a stray value, not a new rule.
 * Full detail in the README's "The messages page" section.
 */
import { useEffect, useMemo, useState } from "react";

import AppNav from "../components/AppNav";
import NotificationsBell from "../components/messages/NotificationsBell";
import ConversationsList from "../components/messages/ConversationsList";
import ChatHeader from "../components/messages/ChatHeader";
import MessageThread from "../components/messages/MessageThread";
import MessageComposer from "../components/messages/MessageComposer";
import NoticeModal from "../components/messages/NoticeModal";
import ReportModal from "../components/messages/ReportModal";

import {
  getConversations,
  getMessages,
  getEarlierMessages,
  sendMessage,
  unmatchUser,
  blockUser,
  reportUser,
} from "../services/postdateApi";

export default function Messages() {
  const [conversations, setConversations] = useState([]);
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [activeId, setActiveId] = useState(null);

  const [messages, setMessages] = useState([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [hasMoreMessages, setHasMoreMessages] = useState(false);

  const [confirmAction, setConfirmAction] = useState(null); // null | "unmatch" | "block"
  const [reportOpen, setReportOpen] = useState(false);
  const [notice, setNotice] = useState("");

  const active = useMemo(
    () => conversations.find((c) => c.matchId === activeId) ?? null,
    [conversations, activeId]
  );

  /* 🔌 BACKEND: GET /api/messages/conversations — see services/postdateApi.js.
     Opens the first match by default, same as Profile.jsx defaulting to its
     first tab. */
  useEffect(() => {
    let cancelled = false;
    getConversations()
      .then((data) => {
        if (cancelled) return;
        setConversations(data);
        if (data.length > 0) openConversation(data[0].matchId);
      })
      .finally(() => !cancelled && setLoadingConversations(false));
    return () => {
      cancelled = true;
    };
  }, []);

  /* 🔌 BACKEND: GET /api/messages/:matchId — reloads whenever the open
     conversation changes. */
  useEffect(() => {
    if (!activeId) {
      setMessages([]);
      setHasMoreMessages(false);
      return;
    }
    let cancelled = false;
    setLoadingMessages(true);
    getMessages(activeId)
      .then(({ messages: initial, hasMore }) => {
        if (cancelled) return;
        setMessages(initial);
        setHasMoreMessages(hasMore);
      })
      .finally(() => !cancelled && setLoadingMessages(false));
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  // Revoke locally-attached photo previews when the page itself closes.
  // While a chat is open, switching conversations drops the previous one's
  // blob: URLs without revoking them — fine for a short session, since a
  // real upload would hand back a permanent URL anyway.
  useEffect(() => {
    return () => {
      messages.forEach((m) => {
        if (m.photoUrl?.startsWith("blob:")) URL.revokeObjectURL(m.photoUrl);
      });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(""), 5000);
    return () => clearTimeout(t);
  }, [notice]);

  // The one place "a conversation becomes active" happens: on first load,
  // on a sidebar click, and after unmatch/block jumps to whatever's next.
  // Opening a conversation — however it happened — clears its unread badge,
  // same as any real chat app.
  function openConversation(matchId) {
    setActiveId(matchId ?? null);
    if (matchId) {
      setConversations((prev) =>
        prev.map((c) => (c.matchId === matchId ? { ...c, unreadCount: 0 } : c))
      );
    }
  }

  async function handleLoadEarlier() {
    if (!activeId) return;
    const { messages: older, hasMore } = await getEarlierMessages(activeId);
    setMessages((prev) => [...older, ...prev]);
    setHasMoreMessages(hasMore);
  }

  async function handleSend({ text, photoFile }) {
    if (!activeId) return;
    const photoUrl = photoFile ? URL.createObjectURL(photoFile) : null;
    const optimistic = {
      id: `local-${Date.now()}`,
      senderId: "me",
      message: text || "",
      photoUrl,
      read: false,
    };

    setMessages((prev) => [...prev, optimistic]);
    setConversations((prev) =>
      prev.map((c) =>
        c.matchId === activeId
          ? { ...c, lastMessage: text || "Sent a photo" }
          : c
      )
    );

    await sendMessage(activeId, { message: text, photoFile });

    // Demo touch: simulate the other person reading it a couple seconds
    // later, so the seen/sent dot actually flips like a live chat would.
    // Swap for a real read-receipt event once the backend sends one.
    setTimeout(() => {
      setMessages((prev) =>
        prev.map((m) => (m.id === optimistic.id ? { ...m, read: true } : m))
      );
    }, 2500);
  }

  async function handleConfirm() {
    if (!active || !confirmAction) return;
    const { matchId, name } = active;

    if (confirmAction === "unmatch") {
      await unmatchUser(matchId);
      setNotice(`You unmatched with ${name}.`);
    } else {
      await blockUser(matchId);
      setNotice(`You blocked ${name}. They won't be able to contact you again.`);
    }

    const remaining = conversations.filter((c) => c.matchId !== matchId);
    setConversations(remaining);
    openConversation(remaining[0]?.matchId ?? null);
    setConfirmAction(null);
  }

  async function handleReportSubmit({ reason, details }) {
    if (!active) return;
    await reportUser(active.matchId, { reason, details });
    setNotice("Report sent — thanks for flagging this.");
    setReportOpen(false);
  }

  return (
    <div className="messages-page">
      <style>{`
        .messages-page {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: var(--pd-pink);
        }

        .messages-main {
          flex: 1;
          width: 100%;
          max-width: var(--pd-max);
          margin: 0 auto;
          padding: clamp(14px, 2vw, 30px) var(--pd-gutter) clamp(28px, 4vw, 56px);
          display: flex;
          flex-direction: column;
          gap: clamp(10px, 1.4vw, 20px);
        }

        .messages-notice {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          margin: 0;
          background: var(--pd-cream);
          border: 2px solid var(--pd-maroon);
          border-radius: 10px;
          padding: 10px 16px;
          font-family: var(--pd-mono);
          font-size: clamp(12px, 1vw, 15px);
          color: var(--pd-ink);
        }
        .messages-notice button {
          flex: none;
          background: none;
          border: none;
          font-size: 18px;
          line-height: 1;
          cursor: pointer;
          color: var(--pd-maroon);
        }

        .messages-card {
          flex: 1;
          background: var(--pd-maroon);
          border-radius: 20px;
          padding: clamp(14px, 2vw, 30px);

          display: grid;
          grid-template-columns: minmax(220px, 20%) minmax(0, 1fr);
          gap: clamp(14px, 2vw, 30px);
          align-items: stretch;
        }

        .messages-panel-wrap {
          border-left: 1px solid var(--pd-white);
          padding-left: clamp(14px, 2vw, 30px);
          min-width: 0;
          display: flex;
        }

        .messages-panel {
          flex: 1;
          background: var(--pd-cream);
          border-radius: 9px;
          padding: clamp(14px, 2vw, 28px);
          min-height: clamp(420px, 58vw, 780px);
          display: flex;
          flex-direction: column;
          min-width: 0;
        }

        .messages-empty {
          margin: auto;
          text-align: center;
          font-family: var(--pd-mono);
          font-size: clamp(13px, 1.2vw, 18px);
          line-height: 1.6;
          color: var(--pd-maroon);
          max-width: 34ch;
        }

        @media (max-width: 760px) {
          .messages-card { grid-template-columns: minmax(0, 1fr); }
          .messages-panel-wrap {
            border-left: none;
            border-top: 1px solid var(--pd-white);
            padding-left: 0;
            padding-top: clamp(14px, 2vw, 24px);
          }
        }
      `}</style>

      <AppNav>
        <NotificationsBell />
      </AppNav>

      <main className="messages-main">
        {notice && (
          <p className="messages-notice" role="status">
            {notice}
            <button type="button" onClick={() => setNotice("")} aria-label="Dismiss">
              ×
            </button>
          </p>
        )}

        <div className="messages-card">
          <ConversationsList
            conversations={conversations}
            loading={loadingConversations}
            activeId={activeId}
            onSelect={openConversation}
          />

          <div className="messages-panel-wrap">
            <section className="messages-panel" aria-live="polite">
              {!active && !loadingConversations && (
                <p className="messages-empty">
                  {conversations.length === 0
                    ? "No conversations yet — matches you like back will show up here."
                    : "Pick a conversation to start chatting."}
                </p>
              )}

              {active && (
                <>
                  <ChatHeader
                    key={active.matchId}
                    conversation={active}
                    onUnmatch={() => setConfirmAction("unmatch")}
                    onBlock={() => setConfirmAction("block")}
                    onReport={() => setReportOpen(true)}
                  />

                  <MessageThread
                    messages={messages}
                    loading={loadingMessages}
                    hasMore={hasMoreMessages}
                    onLoadEarlier={handleLoadEarlier}
                  />

                  <MessageComposer key={active.matchId} onSend={handleSend} />
                </>
              )}
            </section>
          </div>
        </div>
      </main>

      <NoticeModal
        open={confirmAction !== null}
        confirmLabel={confirmAction === "block" ? "Block" : "Unmatch"}
        onClose={() => setConfirmAction(null)}
        onConfirm={handleConfirm}
      >
        Are you sure you want to {confirmAction} <strong>{active?.name}</strong>?
      </NoticeModal>

      <ReportModal
        open={reportOpen}
        name={active?.name}
        onClose={() => setReportOpen(false)}
        onSubmit={handleReportSubmit}
      />
    </div>
  );
}
